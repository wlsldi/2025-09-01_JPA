package com.kh.app0831;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App0831ApplicationTests {

	@Test
	void contextLoads() {
	}

}
